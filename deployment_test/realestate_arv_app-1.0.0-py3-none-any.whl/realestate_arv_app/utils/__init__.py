"""
Utility modules for the ARV calculator application.
"""